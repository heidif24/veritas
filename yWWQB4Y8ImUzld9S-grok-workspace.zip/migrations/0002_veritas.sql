create table if not exists profiles (
  user_id text primary key,
  role text not null default 'student',
  display_name text,
  institution text not null default 'University of Jos',
  domain text not null default 'unijos.edu.ng',
  created_at timestamptz not null default now()
);

create table if not exists courses (
  id text primary key,
  user_id text not null,
  title text not null,
  code text not null,
  join_code text not null unique
);

create index if not exists courses_user_id_idx on courses (user_id);

create table if not exists enrollments (
  course_id text not null,
  user_id text not null,
  primary key (course_id, user_id)
);

create table if not exists assignments (
  id text primary key,
  course_id text not null,
  user_id text not null,
  title text not null,
  paste_threshold double precision not null default 0.15,
  similarity_threshold double precision not null default 0.25,
  created_at timestamptz not null default now()
);

create index if not exists assignments_course_id_idx on assignments (course_id);

create table if not exists documents (
  id text primary key,
  user_id text not null,
  assignment_id text,
  title text not null,
  body text not null default '',
  ops_json text not null default '[]',
  telemetry_json text not null default '{}',
  updated_at timestamptz not null default now()
);

create index if not exists documents_user_id_idx on documents (user_id);

create table if not exists submissions (
  id text primary key,
  document_id text not null,
  assignment_id text,
  user_id text not null,
  body text not null,
  ops_json text not null,
  telemetry_json text not null,
  organic double precision not null,
  paste_share double precision not null,
  similarity double precision not null,
  tab_switches integer not null default 0,
  package_json text,
  sha256 text,
  created_at timestamptz not null default now()
);

create index if not exists submissions_user_id_idx on submissions (user_id);
create index if not exists submissions_assignment_id_idx on submissions (assignment_id);

create table if not exists corpus (
  id text primary key,
  title text not null,
  source_url text,
  body text not null
);

create table if not exists tenant_keys (
  id integer primary key default 1,
  public_pem text not null,
  private_pem text not null
);

create table if not exists tenant_settings (
  user_id text primary key,
  branding_json text not null default '{}',
  lti_json text not null default '{}'
);

insert into corpus (id, title, source_url, body) values
(
  'c1',
  'Academic integrity primer',
  'https://veritas.local/corpus/integrity',
  'Academic integrity is the moral code of academia. It includes values of honesty, trust, fairness, respect, and responsibility. Students who submit work that is not their own undermine the evaluative purpose of assessment. Institutions therefore require authorship to be demonstrated, not merely declared.'
),
(
  'c2',
  'Buffer systems in aqueous chemistry',
  'https://veritas.local/corpus/buffers',
  'A buffer solution resists changes in pH when small amounts of acid or base are added. It typically contains a weak acid and its conjugate base. The Henderson-Hasselbalch equation relates pH to the pKa and the concentration ratio of the conjugate pair. Laboratory reports must record volumes, concentrations, and observed pH rather than generic descriptions.'
),
(
  'c3',
  'Historiography of colonial Nigeria',
  'https://veritas.local/corpus/nigeria',
  'Colonial administration in Northern Nigeria relied on indirect rule, a system that governed through existing emirate structures. Critics argue that this froze social hierarchies and complicated later federal arrangements. Primary sources from district officers should be weighed against oral histories collected after independence.'
)
on conflict (id) do nothing;
