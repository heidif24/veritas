import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cn } from "./app-shell-BUO8FR6J.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/analyze-B7AODtBQ.js
var import_jsx_runtime = require_jsx_runtime();
var LABEL = {
	human: "Human-typed",
	mixed: "Mixed origin",
	pasted: "Mostly pasted",
	empty: "Waiting"
};
function OriginMeter({ report }) {
	const tone = report.verdict === "human" ? "text-sage" : report.verdict === "pasted" ? "text-primary" : report.verdict === "mixed" ? "text-primary" : "text-muted";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.14em] text-muted",
				children: "Origin"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-2 font-display text-3xl tracking-tight", tone),
				children: LABEL[report.verdict]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: ["Human-likelihood ", report.verdict === "empty" ? "—" : `${report.humanScore}`]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 h-1.5 overflow-hidden rounded-full bg-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("h-full rounded-full transition-[width] duration-300", report.verdict === "human" ? "bg-sage" : "bg-primary"),
					style: { width: `${report.verdict === "empty" ? 0 : report.humanScore}%` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-5 grid grid-cols-2 gap-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Typed",
						v: String(report.typedChars)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Pasted",
						v: String(report.pastedChars)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Median key gap",
						v: report.medianIki != null ? `${Math.round(report.medianIki)} ms` : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Revisions",
						v: `${Math.round(report.revisionRatio * 100)}%`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-5 space-y-2 text-sm text-muted",
				children: report.notes.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "leading-relaxed",
					children: n
				}, n))
			})
		]
	});
}
function Stat({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "text-xs text-muted",
		children: k
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "mt-0.5 font-medium tabular-nums",
		children: v
	})] });
}
var AI_PHRASES = [
	"in today's rapidly",
	"it is important to note",
	"it's important to note",
	"in conclusion",
	"furthermore",
	"moreover",
	"delve into",
	"a testament to",
	"plays a crucial role",
	"in the ever-evolving",
	"landscape of",
	"robust and",
	"leverage",
	"unlock the potential",
	"as an ai language model",
	"i hope this helps",
	"tapestry",
	"multifaceted",
	"holistic approach",
	"in a world where"
];
function median(values) {
	if (!values.length) return null;
	const s = [...values].sort((a, b) => a - b);
	const mid = Math.floor(s.length / 2);
	return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}
function sentences(text) {
	return text.split(/[.!?]+/).map((s) => s.trim()).filter((s) => s.length > 8);
}
function analyzeTextSignals(text) {
	const words = text.toLowerCase().match(/[a-zA-Z\u4e00-\u9fff']+/g) ?? [];
	const unique = new Set(words);
	const lexicalDiversity = words.length ? unique.size / words.length : 0;
	const lengths = sentences(text).map((s) => s.split(/\s+/).length);
	const mean = lengths.length ? lengths.reduce((a, b) => a + b, 0) / lengths.length : 0;
	const variance = lengths.length ? lengths.reduce((a, b) => a + (b - mean) ** 2, 0) / lengths.length : 0;
	const burstiness = mean > 0 ? variance / mean : 0;
	const hay = text.toLowerCase();
	return {
		lexicalDiversity,
		burstiness,
		aiPhraseHits: AI_PHRASES.reduce((n, p) => n + (hay.includes(p) ? 1 : 0), 0),
		wordCount: words.length
	};
}
function analyzeSession(text, strokes) {
	const now = Date.now();
	const first = strokes[0]?.t ?? now;
	const last = strokes[strokes.length - 1]?.t ?? now;
	const durationMs = Math.max(0, last - first);
	let typedChars = 0;
	let pastedChars = 0;
	let deletedChars = 0;
	const iki = [];
	let prevKey = null;
	for (const s of strokes) {
		if (s.kind === "paste") pastedChars += s.chars;
		else if (s.kind === "delete") deletedChars += s.chars;
		else typedChars += s.chars;
		if (s.kind === "key" && s.chars > 0) {
			if (prevKey != null) {
				const gap = s.t - prevKey;
				if (gap > 12 && gap < 2e3) iki.push(gap);
			}
			prevKey = s.t;
		} else if (s.kind === "paste") prevKey = null;
	}
	const totalIn = typedChars + pastedChars;
	const pasteShare = totalIn ? pastedChars / totalIn : 0;
	const revisionRatio = typedChars ? deletedChars / typedChars : 0;
	const medianIki = median(iki);
	const textSignals = analyzeTextSignals(text);
	const notes = [];
	if (!text.trim()) return {
		verdict: "empty",
		humanScore: 0,
		pasteShare: 0,
		typedChars,
		pastedChars,
		deletedChars,
		durationMs: 0,
		medianIki: null,
		revisionRatio: 0,
		burstiness: 0,
		lexicalDiversity: 0,
		aiPhraseHits: 0,
		notes: ["Start typing in the field. Cadence never reads other apps."]
	};
	let human = 55;
	if (pasteShare > .7 && pastedChars > 40) {
		human -= 40;
		notes.push("Most of this text arrived in a paste, not keystrokes.");
	} else if (pasteShare > .25) {
		human -= 18;
		notes.push("A noticeable share of the draft was pasted.");
	} else if (typedChars > 40 && pasteShare < .05) {
		human += 18;
		notes.push("Almost every character was typed in this box.");
	}
	if (medianIki != null) {
		if (medianIki >= 70 && medianIki <= 280) {
			human += 12;
			notes.push("Keystroke gaps look like a person composing.");
		} else if (medianIki < 35 && iki.length > 20) {
			human -= 16;
			notes.push("Keystroke timing is unusually even and fast.");
		}
	} else if (pastedChars > typedChars) notes.push("Too few keystrokes to judge typing cadence.");
	if (revisionRatio > .08 && typedChars > 30) {
		human += 8;
		notes.push("Edits and deletions while writing — typical of drafting.");
	} else if (typedChars > 80 && revisionRatio < .01 && pasteShare < .1) {
		human -= 6;
		notes.push("Almost no revisions while producing a long draft.");
	}
	if (textSignals.aiPhraseHits >= 3) {
		human -= 16;
		notes.push(`${textSignals.aiPhraseHits} stock AI phrases showed up in the language.`);
	} else if (textSignals.aiPhraseHits === 0 && textSignals.wordCount > 40) human += 4;
	if (textSignals.burstiness < .4 && textSignals.wordCount > 80) {
		human -= 8;
		notes.push("Sentence length is unusually uniform.");
	} else if (textSignals.burstiness > 1.1) human += 5;
	if (textSignals.lexicalDiversity > 0 && textSignals.lexicalDiversity < .32 && textSignals.wordCount > 60) {
		human -= 6;
		notes.push("Word choice is repetitive relative to length.");
	}
	human = Math.max(4, Math.min(96, Math.round(human)));
	let verdict = "human";
	if (pasteShare > .65 && pastedChars > 40) verdict = "pasted";
	else if (human < 48 || pasteShare > .2 && textSignals.aiPhraseHits >= 2) verdict = "mixed";
	else verdict = "human";
	if (!notes.length) notes.push("Signals are mixed; treat this as a hint, not a verdict in court.");
	return {
		verdict,
		humanScore: human,
		pasteShare,
		typedChars,
		pastedChars,
		deletedChars,
		durationMs,
		medianIki,
		revisionRatio,
		burstiness: textSignals.burstiness,
		lexicalDiversity: textSignals.lexicalDiversity,
		aiPhraseHits: textSignals.aiPhraseHits,
		notes
	};
}
var SAMPLE_AI = `In today's rapidly evolving educational landscape, it is important to note that academic integrity plays a crucial role in fostering a holistic approach to learning. Furthermore, institutions must delve into robust and multifaceted strategies to unlock the potential of every learner. Moreover, this tapestry of assessment design is a testament to our shared values. In conclusion, a proactive stance will ensure success in the ever-evolving world of higher education.`;
var SAMPLE_HUMAN = `Office hours Thursday after the lab — I still don't get why the pH dropped when we added the buffer. I rewrote the methods twice and the numbers still look off. Can I bring the notebook?`;
//#endregion
export { analyzeSession as i, SAMPLE_AI as n, SAMPLE_HUMAN as r, OriginMeter as t };
