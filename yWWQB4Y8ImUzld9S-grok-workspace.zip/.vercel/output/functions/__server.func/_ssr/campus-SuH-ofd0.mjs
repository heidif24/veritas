import { _ as Link, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cn, t as AppShell } from "./app-shell-BUO8FR6J.mjs";
import { r as useCampusStore, t as Button } from "./campus-store-WRcOlk3D.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/campus-SuH-ofd0.js
var import_jsx_runtime = require_jsx_runtime();
function CampusPage() {
	const submissions = useCampusStore((s) => s.submissions);
	const clear = useCampusStore((s) => s.clear);
	const counts = submissions.reduce((acc, row) => {
		acc[row.verdict] += 1;
		return acc;
	}, {
		human: 0,
		mixed: 0,
		pasted: 0,
		empty: 0
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.16em] text-muted",
					children: "University view"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-4xl tracking-tight",
					children: "Campus inbox"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-xl text-muted leading-relaxed",
					children: "Sample plus anything you file from Studio. Stored on this device only — no accounts, no network."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "outline",
				onClick: clear,
				children: "Reset sample"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid grid-cols-3 gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
					label: "Human-typed",
					value: counts.human,
					tone: "sage"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
					label: "Mixed",
					value: counts.mixed,
					tone: "primary"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
					label: "Pasted",
					value: counts.pasted,
					tone: "primary"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-8 divide-y divide-border rounded-2xl bg-surface shadow-[var(--shadow-border)]",
			children: submissions.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, { row }, row.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-6 text-sm text-muted",
			children: [
				"File a draft from",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "text-fg underline decoration-border underline-offset-4",
					children: "Studio"
				}),
				" ",
				"to see it land here."
			]
		})
	] });
}
function Kpi({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("mt-1 font-display text-3xl tabular-nums", tone === "sage" ? "text-sage" : "text-primary"),
			children: value
		})]
	});
}
function Row({ row }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex flex-col gap-2 px-4 py-4 sm:flex-row sm:items-center sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm font-medium",
			children: [row.course, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-muted font-normal",
				children: [" · ", row.title]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: row.excerpt
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3 text-sm tabular-nums",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("rounded-full px-2.5 py-1 text-xs font-medium", row.verdict === "human" ? "bg-sage/10 text-sage" : "bg-primary/10 text-primary"),
				children: row.verdict
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted",
				children: row.humanScore
			})]
		})]
	});
}
//#endregion
export { CampusPage as component };
