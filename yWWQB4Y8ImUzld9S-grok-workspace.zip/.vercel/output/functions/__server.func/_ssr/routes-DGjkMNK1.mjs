import { i as __toESM } from "../_runtime.mjs";
import { R as require_react, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as AppShell } from "./app-shell-BUO8FR6J.mjs";
import { i as analyzeSession, n as SAMPLE_AI, r as SAMPLE_HUMAN, t as OriginMeter } from "./analyze-B7AODtBQ.mjs";
import { n as reportToSubmission, r as useCampusStore, t as Button } from "./campus-store-WRcOlk3D.mjs";
import { a as ClipboardPaste, i as Eraser, n as Send, r as Keyboard } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DGjkMNK1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Composer() {
	const [text, setText] = (0, import_react.useState)("");
	const [strokes, setStrokes] = (0, import_react.useState)([]);
	const [course, setCourse] = (0, import_react.useState)("WRIT 120");
	const [title, setTitle] = (0, import_react.useState)("In-class response");
	const [toast, setToast] = (0, import_react.useState)(null);
	const prevLen = (0, import_react.useRef)(0);
	const pasteChars = (0, import_react.useRef)(0);
	const submit = useCampusStore((s) => s.submit);
	const report = (0, import_react.useMemo)(() => analyzeSession(text, strokes), [text, strokes]);
	function pushStroke(kind, chars) {
		const n = Math.abs(chars);
		if (!n) return;
		setStrokes((s) => [...s, {
			t: Date.now(),
			kind,
			chars: n
		}]);
	}
	function onPaste(e) {
		pasteChars.current = (e.clipboardData.getData("text") ?? "").length;
	}
	function onChange(e) {
		const next = e.target.value;
		const delta = next.length - prevLen.current;
		if (pasteChars.current > 0) {
			pushStroke("paste", pasteChars.current);
			pasteChars.current = 0;
		} else if (delta > 8) pushStroke("paste", delta);
		else if (delta < 0) pushStroke("delete", -delta);
		else if (delta > 0) pushStroke("key", delta);
		prevLen.current = next.length;
		setText(next);
	}
	function loadSample(sample, asPaste) {
		setText(sample);
		prevLen.current = sample.length;
		pasteChars.current = 0;
		setStrokes(asPaste ? [{
			t: Date.now(),
			kind: "paste",
			chars: sample.length
		}] : sample.split("").map((_, i) => ({
			t: Date.now() + i * 110,
			kind: "key",
			chars: 1
		})));
	}
	function reset() {
		setText("");
		setStrokes([]);
		prevLen.current = 0;
		pasteChars.current = 0;
	}
	function onSubmit() {
		if (!text.trim()) return;
		submit(reportToSubmission(report, text, course, title));
		setToast("Filed to Campus — still only on this device.");
		window.setTimeout(() => setToast(null), 2800);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[minmax(0,1fr)_20rem]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: "draft",
				className: "sr-only",
				children: "Draft"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				id: "draft",
				value: text,
				onChange,
				onPaste,
				placeholder: "Type here. Paste an AI draft if you want to see it flagged. Nothing leaves this browser.",
				className: "min-h-[22rem] w-full resize-y rounded-2xl bg-surface p-5 text-base leading-relaxed text-fg shadow-[var(--shadow-border)] placeholder:text-muted/80 focus:outline-2 focus:outline-offset-2 focus:outline-primary"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => loadSample(SAMPLE_AI, true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardPaste, { className: "size-4" }), "Paste AI sample"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => loadSample(SAMPLE_HUMAN, false),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Keyboard, { className: "size-4" }), "Human sample"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "ghost",
						onClick: reset,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eraser, { className: "size-4" }), "Clear"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-col gap-3 sm:flex-row sm:items-end",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex-1 text-xs text-muted",
						children: ["Course", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: course,
							onChange: (e) => setCourse(e.target.value),
							className: "mt-1 min-h-11 w-full rounded-xl bg-surface px-3 text-sm text-fg shadow-[var(--shadow-border)]"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex-[1.4] text-xs text-muted",
						children: ["Assignment", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: title,
							onChange: (e) => setTitle(e.target.value),
							className: "mt-1 min-h-11 w-full rounded-xl bg-surface px-3 text-sm text-fg shadow-[var(--shadow-border)]"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "sage",
						onClick: onSubmit,
						disabled: !text.trim(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" }), "File to campus"]
					})
				]
			}),
			toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-sage",
				role: "status",
				children: toast
			}) : null
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OriginMeter, { report })]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.16em] text-muted",
				children: "Offline · for campuses"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl tracking-tight sm:text-5xl",
				children: "Was this typed, or dropped in from somewhere else?"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-xl text-base leading-relaxed text-muted",
				children: "Cadence does not open other AI apps. It watches this field: keystrokes, pastes, pauses, and a few language tells — so a message can be a person’s, not a dump from a chatbot."
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Composer, {})
	})] });
}
//#endregion
export { Home as component };
