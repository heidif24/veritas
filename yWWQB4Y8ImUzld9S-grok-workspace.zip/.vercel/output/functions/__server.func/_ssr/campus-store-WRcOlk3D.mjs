import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as cn } from "./app-shell-BUO8FR6J.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/campus-store-WRcOlk3D.js
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 rounded-xl text-sm font-medium transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary disabled:pointer-events-none disabled:opacity-40 min-h-11 px-4", {
	variants: { variant: {
		primary: "bg-primary text-surface hover:bg-primary/90",
		sage: "bg-sage text-surface hover:bg-sage/90",
		ghost: "bg-transparent text-fg hover:bg-fg/5 shadow-none",
		outline: "bg-surface text-fg hover:bg-bg"
	} },
	defaultVariants: { variant: "primary" }
});
function Button({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn(buttonVariants({ variant }), className),
		...props
	});
}
var SEED = [
	{
		id: "seed-1",
		at: Date.now() - 1728e5,
		course: "CHEM 210",
		title: "Lab 4 reflection",
		excerpt: "The pH dropped when we added the buffer…",
		verdict: "human",
		humanScore: 82,
		pasteShare: .02
	},
	{
		id: "seed-2",
		at: Date.now() - 864e5,
		course: "HIST 101",
		title: "Week 6 response",
		excerpt: "In today's rapidly evolving educational landscape…",
		verdict: "pasted",
		humanScore: 18,
		pasteShare: .94
	},
	{
		id: "seed-3",
		at: Date.now() - 18e6,
		course: "WRIT 120",
		title: "Draft intro",
		excerpt: "I started from notes then pasted a paragraph to rewrite…",
		verdict: "mixed",
		humanScore: 51,
		pasteShare: .41
	}
];
var useCampusStore = create()(persist((set) => ({
	submissions: SEED,
	submit: (row) => set((s) => ({ submissions: [{
		...row,
		id: crypto.randomUUID(),
		at: Date.now()
	}, ...s.submissions].slice(0, 40) })),
	clear: () => set({ submissions: SEED })
}), { name: "cadence-campus" }));
function reportToSubmission(report, text, course, title) {
	const excerpt = text.trim().replace(/\s+/g, " ").slice(0, 90);
	return {
		course,
		title,
		excerpt: excerpt ? `${excerpt}${text.trim().length > 90 ? "…" : ""}` : "(empty)",
		verdict: report.verdict === "empty" ? "mixed" : report.verdict,
		humanScore: report.humanScore,
		pasteShare: report.pasteShare
	};
}
//#endregion
export { reportToSubmission as n, useCampusStore as r, Button as t };
