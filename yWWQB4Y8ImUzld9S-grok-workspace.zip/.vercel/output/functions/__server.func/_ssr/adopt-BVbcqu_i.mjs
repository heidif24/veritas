import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as AppShell } from "./app-shell-BUO8FR6J.mjs";
import { i as analyzeSession, n as SAMPLE_AI, t as OriginMeter } from "./analyze-B7AODtBQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/adopt-BVbcqu_i.js
var import_jsx_runtime = require_jsx_runtime();
var snippet = `<script src="https://cadence.example/embed.js" data-field="#essay"><\/script>`;
var pastedReport = analyzeSession(SAMPLE_AI, [{
	t: Date.now(),
	kind: "paste",
	chars: SAMPLE_AI.length
}]);
function AdoptPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.16em] text-muted",
				children: "Sites · LMS · Microsoft-style desktop later"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl tracking-tight sm:text-5xl",
				children: "One field. Any campus site can adopt it."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-muted leading-relaxed",
				children: "Drop Cadence on an assignment box, a discussion post, or an internal form. It runs in the page — no login, no cloud scan of student work in this demo. Instructors see origin on the same terms as Studio."
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-10 grid gap-6 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.14em] text-muted",
					children: "Embed"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "mt-4 overflow-x-auto rounded-xl bg-fg px-4 py-4 text-xs leading-relaxed text-bg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: snippet })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "mt-5 list-decimal space-y-2 pl-5 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Point it at the textarea students already use." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Cadence records paste vs type in that field only." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The badge travels with the submission to the campus inbox." })
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-xs font-medium uppercase tracking-[0.14em] text-muted",
				children: "LMS widget preview"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "Discussion · HIST 101"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 rounded-xl bg-bg px-3 py-3 text-sm leading-relaxed text-muted",
					children: [SAMPLE_AI.slice(0, 180), "…"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OriginMeter, { report: pastedReport })
			})
		] })]
	})] });
}
//#endregion
export { AdoptPage as component };
