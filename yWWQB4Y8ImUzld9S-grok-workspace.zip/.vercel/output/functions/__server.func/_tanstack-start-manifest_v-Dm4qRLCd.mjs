//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dm4qRLCd.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/adopt",
			"/campus"
		],
		preloads: ["/assets/index-BP-zk-3N.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BP-zk-3N.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Bh8GzXd_.js",
			"/assets/app-shell-B3LQpBAD.js",
			"/assets/analyze-BAypElQa.js",
			"/assets/campus-store-CGcvKyj6.js"
		]
	},
	"/adopt": {
		filePath: "/workspace/src/routes/adopt.tsx",
		children: void 0,
		preloads: [
			"/assets/adopt-C2-BggMD.js",
			"/assets/app-shell-B3LQpBAD.js",
			"/assets/analyze-BAypElQa.js"
		]
	},
	"/campus": {
		filePath: "/workspace/src/routes/campus.tsx",
		children: void 0,
		preloads: [
			"/assets/campus-C6NoXAgr.js",
			"/assets/app-shell-B3LQpBAD.js",
			"/assets/campus-store-CGcvKyj6.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
