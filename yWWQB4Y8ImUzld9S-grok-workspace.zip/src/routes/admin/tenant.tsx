import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { RequireAuth } from "@/components/gate";
import { Button } from "@/components/ui/button";
import { getMe, loadTenant, saveTenant, setRole } from "@/lib/veritas/api";

export const Route = createFileRoute("/admin/tenant")({ component: Page });

function Page() {
  return (
    <AppShell>
      <RequireAuth>
        <Tenant />
      </RequireAuth>
    </AppShell>
  );
}

function Tenant() {
  const [name, setName] = useState("University of Jos");
  const [domain, setDomain] = useState("unijos.edu.ng");
  const [msg, setMsg] = useState<string | null>(null);
  useEffect(() => {
    void Promise.all([getMe(), loadTenant()]).then(([me, t]) => {
      setName(t.branding.institution || me.institution);
      setDomain(t.branding.domain || me.domain);
    });
  }, []);
  return (
    <form
      className="max-w-lg space-y-4"
      onSubmit={(e) => {
        e.preventDefault();
        void Promise.all([
          setRole({ data: { role: "admin", institution: name, domain } }),
          saveTenant({
            data: { branding: { institution: name, domain }, lti: {} },
          }),
        ]).then(() => setMsg("Tenant saved on this account."));
      }}
    >
      <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Admin</p>
      <h1 className="font-display text-4xl tracking-tight">Tenant</h1>
      <p className="text-sm text-muted leading-relaxed">
        Isolated per signed-in institution admin. Email domain whitelist is stored
        here; enforcement is applied when members join with a matching campus domain.
      </p>
      <label className="block text-sm text-muted">
        Institution
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="mt-1 min-h-11 w-full rounded-xl bg-surface px-3 text-fg shadow-[var(--shadow-border)]"
        />
      </label>
      <label className="block text-sm text-muted">
        Whitelisted domain
        <input
          value={domain}
          onChange={(e) => setDomain(e.target.value)}
          className="mt-1 min-h-11 w-full rounded-xl bg-surface px-3 text-fg shadow-[var(--shadow-border)]"
        />
      </label>
      <Button type="submit">Save branding</Button>
      {msg ? <p className="text-sm text-sage">{msg}</p> : null}
    </form>
  );
}
