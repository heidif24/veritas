import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { RequireAuth } from "@/components/gate";
import { Button } from "@/components/ui/button";
import { loadTenant, saveTenant } from "@/lib/veritas/api";

export const Route = createFileRoute("/admin/integrations")({ component: Page });

function Page() {
  return (
    <AppShell>
      <RequireAuth>
        <Integrations />
      </RequireAuth>
    </AppShell>
  );
}

function Integrations() {
  const [issuer, setIssuer] = useState("");
  const [client, setClient] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  useEffect(() => {
    void loadTenant().then((t) => {
      setIssuer(t.lti.issuer ?? "");
      setClient(t.lti.client_id ?? "");
    });
  }, []);
  return (
    <form
      className="max-w-lg space-y-4"
      onSubmit={(e) => {
        e.preventDefault();
        void saveTenant({
          data: {
            branding: {},
            lti: { issuer, client_id: client, version: "1.3" },
          },
        }).then(() =>
          setMsg("LTI 1.3 credentials stored. Live grade passback needs a registered LMS tool."),
        );
      }}
    >
      <h1 className="font-display text-4xl tracking-tight">LMS integrations</h1>
      <p className="text-sm text-muted leading-relaxed">
        Canvas, Moodle, and Blackboard talk LTI 1.3. This page stores the tool
        issuer and client id for the tenant. Roster sync and grade passback
        activate after the LMS admin registers Veritas as an external tool —
        this demo does not fake a live Canvas session.
      </p>
      <label className="block text-sm text-muted">
        Issuer
        <input
          value={issuer}
          onChange={(e) => setIssuer(e.target.value)}
          placeholder="https://canvas.unijos.edu.ng"
          className="mt-1 min-h-11 w-full rounded-xl bg-surface px-3 text-fg shadow-[var(--shadow-border)]"
        />
      </label>
      <label className="block text-sm text-muted">
        Client id
        <input
          value={client}
          onChange={(e) => setClient(e.target.value)}
          className="mt-1 min-h-11 w-full rounded-xl bg-surface px-3 text-fg shadow-[var(--shadow-border)]"
        />
      </label>
      <Button type="submit">Save LTI config</Button>
      {msg ? <p className="text-sm text-sage">{msg}</p> : null}
    </form>
  );
}
