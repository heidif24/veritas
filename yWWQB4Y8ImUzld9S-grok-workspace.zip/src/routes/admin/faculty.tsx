import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { RequireAuth } from "@/components/gate";
import { listFaculty } from "@/lib/veritas/api";

export const Route = createFileRoute("/admin/faculty")({ component: Page });

function Page() {
  return (
    <AppShell>
      <RequireAuth>
        <Faculty />
      </RequireAuth>
    </AppShell>
  );
}

function Faculty() {
  const [rows, setRows] = useState<Awaited<ReturnType<typeof listFaculty>>>([]);
  useEffect(() => {
    void listFaculty().then(setRows);
  }, []);
  return (
    <div>
      <h1 className="font-display text-4xl tracking-tight">Faculty</h1>
      <p className="mt-3 max-w-xl text-sm text-muted">
        Profiles visible to this tenant. Bulk CSV onboarding ships when an SIS
        connector is attached — this queue is the live roster from Veritas itself.
      </p>
      <ul className="mt-8 divide-y divide-border rounded-2xl bg-surface shadow-[var(--shadow-border)]">
        {rows.map((r) => (
          <li key={r.user_id} className="flex items-center justify-between px-4 py-3 text-sm">
            <span>{r.display_name || r.user_id.slice(0, 8)}</span>
            <span className="text-muted">
              {r.role} · {r.institution}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
