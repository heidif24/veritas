import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell } from "@/components/app-shell";
import { verifyPackageFn } from "@/lib/veritas/api";

export const Route = createFileRoute("/verify")({ component: VerifyPage });

function VerifyPage() {
  const [status, setStatus] = useState<{ ok: boolean; reason: string; sha256?: string } | null>(
    null,
  );
  const [busy, setBusy] = useState(false);

  async function onFile(file: File) {
    setBusy(true);
    try {
      const text = await file.text();
      const json = JSON.parse(text);
      const res = await verifyPackageFn({ data: json });
      setStatus(res);
    } catch {
      setStatus({ ok: false, reason: "Could not parse this file as a .veritas bundle." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <AppShell>
      <h1 className="font-display text-4xl tracking-tight">Verification portal</h1>
      <p className="mt-3 max-w-xl text-muted leading-relaxed">
        Drop a <code>.veritas</code> package. We recompute the SHA-256 of the
        payload and check the Ed25519 signature. External edits fail closed.
      </p>
      <label className="mt-8 flex min-h-40 cursor-pointer flex-col items-center justify-center rounded-2xl bg-surface px-6 text-center shadow-[var(--shadow-border)]">
        <span className="text-sm text-muted">
          {busy ? "Checking…" : "Drop a .veritas file or click to browse"}
        </span>
        <input
          type="file"
          accept=".veritas,application/json"
          className="sr-only"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) void onFile(f);
          }}
        />
      </label>
      {status ? (
        <div
          className={`mt-6 rounded-2xl p-5 shadow-[var(--shadow-border)] ${
            status.ok ? "bg-surface" : "bg-primary text-surface"
          }`}
        >
          <p className="font-display text-2xl">
            {status.ok ? "Seal intact" : "Critical tamper alert"}
          </p>
          <p className="mt-2 text-sm leading-relaxed opacity-90">{status.reason}</p>
          {status.sha256 ? (
            <p className="mt-3 break-all font-mono text-xs opacity-80">{status.sha256}</p>
          ) : null}
        </div>
      ) : null}
    </AppShell>
  );
}
