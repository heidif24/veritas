import { createFileRoute, Link } from "@tanstack/react-router";
import { GROK_PROVIDERS, authEnabled, signIn } from "@/lib/auth/client";
import { AppShell } from "@/components/app-shell";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  return (
    <AppShell>
      <div className="mx-auto max-w-sm space-y-4 pt-8">
        <h1 className="font-display text-3xl tracking-tight">Sign in to Veritas</h1>
        <p className="text-sm text-muted leading-relaxed">
          Google or X. Campus SSO via the Grok gate when this app is opened from Grok.
        </p>
        {authEnabled ? (
          GROK_PROVIDERS.map((p) => (
            <button
              key={p.providerId}
              type="button"
              onClick={() => signIn(p.providerId, { callbackURL: "/app/dashboard" })}
              className="w-full min-h-11 rounded-xl bg-fg px-4 text-sm text-bg hover:bg-fg/90"
            >
              Continue with {p.label}
            </button>
          ))
        ) : (
          <p className="text-sm text-muted">Sign-in is disabled.</p>
        )}
        <Link to="/" className="block text-sm text-muted underline underline-offset-4">
          Back
        </Link>
      </div>
    </AppShell>
  );
}
