import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { RequireAuth } from "@/components/gate";
import { Button } from "@/components/ui/button";
import { WritingCanvas } from "@/components/writing-canvas";
import {
  checkOriginality,
  listAssignments,
  listMyCourses,
  loadDocument,
  saveDocument,
  submitAndSeal,
} from "@/lib/veritas/api";
import type { Op, Telemetry } from "@/lib/veritas/ops";
import { emptyTelemetry } from "@/lib/veritas/ops";
import type { MatchHit } from "@/lib/veritas/ngrams";

export const Route = createFileRoute("/app/editor/$id")({ component: Page });

function Page() {
  return (
    <AppShell>
      <RequireAuth>
        <Editor />
      </RequireAuth>
    </AppShell>
  );
}

function Editor() {
  const { id } = Route.useParams();
  const [title, setTitle] = useState("Untitled draft");
  const [body, setBody] = useState("");
  const [ops, setOps] = useState<Op[]>([]);
  const [telemetry, setTelemetry] = useState<Telemetry>(emptyTelemetry());
  const [assignmentId, setAssignmentId] = useState<string | null>(null);
  const [assignments, setAssignments] = useState<Array<{ id: string; title: string }>>([]);
  const [hits, setHits] = useState<MatchHit[]>([]);
  const [msg, setMsg] = useState<string | null>(null);
  const [blocked, setBlocked] = useState<string | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    void loadDocument({ data: id }).then((d) => {
      setTitle(d.title);
      setBody(d.body);
      setOps(JSON.parse(d.ops_json) as Op[]);
      const t = JSON.parse(d.telemetry_json) as Telemetry;
      setTelemetry({ ...emptyTelemetry(), ...t });
      setAssignmentId(d.assignment_id);
      setLoaded(true);
    });
    void listMyCourses().then(async (courses) => {
      const all: Array<{ id: string; title: string }> = [];
      for (const c of courses) {
        const list = await listAssignments({ data: c.id });
        for (const a of list) all.push({ id: a.id, title: `${c.code} · ${a.title}` });
      }
      setAssignments(all);
    });
  }, [id]);

  const onChange = useCallback(
    (n: { body: string; ops: Op[]; telemetry: Telemetry }) => {
      setBody(n.body);
      setOps(n.ops);
      setTelemetry(n.telemetry);
    },
    [],
  );

  async function persist() {
    await saveDocument({
      data: { id, title, body, ops, telemetry, assignment_id: assignmentId },
    });
    setMsg("Saved in this workspace.");
  }

  async function originality() {
    const res = await checkOriginality({ data: { text: body } });
    setHits(res.hits);
    setMsg(`Similarity ${(res.score * 100).toFixed(1)}% vs corpus.`);
  }

  async function seal(force = false) {
    await persist();
    const res = await submitAndSeal({
      data: {
        document_id: id,
        assignment_id: assignmentId,
        title,
        body,
        ops,
        telemetry,
        force,
      },
    });
    if (res.blocked) {
      setBlocked(
        `Pre-submission gate: paste ${(res.health.pasteShare * 100).toFixed(0)}% (limit ${(res.pasteGate * 100).toFixed(0)}%) · similarity ${(res.originality.score * 100).toFixed(0)}% (limit ${(res.simGate * 100).toFixed(0)}%). Resolve or override.`,
      );
      setHits(res.originality.hits);
      return;
    }
    setBlocked(null);
    const blob = new Blob([JSON.stringify(res.bundle, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${title.replace(/\s+/g, "-")}.veritas`;
    a.click();
    URL.revokeObjectURL(url);
    setMsg("Sealed. The .veritas bundle downloaded — take it to Verify.");
  }

  return (
    <div>
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        className="w-full bg-transparent font-display text-3xl tracking-tight focus:outline-none"
      />
      <div className="mt-4 flex flex-wrap gap-2">
        <select
          value={assignmentId ?? ""}
          onChange={(e) => setAssignmentId(e.target.value || null)}
          className="min-h-11 rounded-xl bg-surface px-3 text-sm shadow-[var(--shadow-border)]"
        >
          <option value="">No dropbox</option>
          {assignments.map((a) => (
            <option key={a.id} value={a.id}>
              {a.title}
            </option>
          ))}
        </select>
        <Button variant="outline" onClick={() => void persist()}>
          Save
        </Button>
        <Button variant="outline" onClick={() => void originality()}>
          Originality
        </Button>
        <Button variant="primary" onClick={() => void seal(false)}>
          Seal & export
        </Button>
      </div>
      {msg ? <p className="mt-3 text-sm text-sage">{msg}</p> : null}
      {blocked ? (
        <div className="mt-3 rounded-2xl bg-primary p-4 text-sm text-surface">
          <p>{blocked}</p>
          <Button className="mt-3 bg-surface text-fg" onClick={() => void seal(true)}>
            Override gate
          </Button>
        </div>
      ) : null}
      {loaded ? (
      <div className="mt-6">
        <WritingCanvas
          key={id}
          body={body}
          ops={ops}
          telemetry={telemetry}
          onChange={onChange}
          hits={hits}
          footer={
            hits.length ? (
              <aside className="mt-4 rounded-2xl bg-surface p-4 text-sm shadow-[var(--shadow-border)]">
                <p className="font-medium">Matched sources</p>
                <ul className="mt-2 space-y-2 text-muted">
                  {hits.map((h) => (
                    <li key={h.sourceId + h.gram}>
                      {h.title} · {(h.overlap * 100).toFixed(1)}% · “{h.gram}”
                    </li>
                  ))}
                </ul>
              </aside>
            ) : null
          }
        />
      </div>
      ) : (
        <p className="mt-6 text-sm text-muted">Opening canvas…</p>
      )}
    </div>
  );
}
