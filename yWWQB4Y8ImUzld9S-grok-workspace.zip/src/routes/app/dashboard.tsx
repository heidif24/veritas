import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { RequireAuth } from "@/components/gate";
import { Button } from "@/components/ui/button";
import {
  createDocument,
  getMe,
  joinCourse,
  listDocuments,
  listMyCourses,
  setRole,
} from "@/lib/veritas/api";

export const Route = createFileRoute("/app/dashboard")({ component: Page });

function Page() {
  return (
    <AppShell>
      <RequireAuth>
        <Dash />
      </RequireAuth>
    </AppShell>
  );
}

function Dash() {
  const nav = useNavigate();
  const [docs, setDocs] = useState<Awaited<ReturnType<typeof listDocuments>>>([]);
  const [courses, setCourses] = useState<Awaited<ReturnType<typeof listMyCourses>>>([]);
  const [role, setRoleState] = useState("student");
  const [join, setJoin] = useState("");
  const [err, setErr] = useState<string | null>(null);

  async function refresh() {
    const [d, c, me] = await Promise.all([listDocuments(), listMyCourses(), getMe()]);
    setDocs(d);
    setCourses(c);
    setRoleState(me.role);
  }

  useEffect(() => {
    void refresh().catch((e) => setErr(String(e)));
  }, []);

  async function newDraft() {
    const { id } = await createDocument({ data: { title: "Untitled draft" } });
    await nav({ to: "/app/editor/$id", params: { id } });
  }

  return (
    <div>
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">
            Student workspace
          </p>
          <h1 className="mt-2 font-display text-4xl tracking-tight">Drafts</h1>
        </div>
        <Button onClick={() => void newDraft()}>New draft</Button>
      </div>
      {err ? <p className="mt-4 text-sm text-primary">{err}</p> : null}

      <div className="mt-6 flex flex-wrap items-center gap-2 text-sm">
        <span className="text-muted">Role</span>
        {(["student", "instructor", "admin"] as const).map((r) => (
          <button
            key={r}
            type="button"
            className={`min-h-11 rounded-full px-3 ${role === r ? "bg-fg text-bg" : "bg-surface"}`}
            onClick={() => {
              void setRole({ data: { role: r } }).then(() => setRoleState(r));
            }}
          >
            {r}
          </button>
        ))}
      </div>

      <ul className="mt-8 divide-y divide-border rounded-2xl bg-surface shadow-[var(--shadow-border)]">
        {docs.length === 0 ? (
          <li className="px-4 py-8 text-sm text-muted">No drafts yet.</li>
        ) : (
          docs.map((d) => (
            <li key={d.id}>
              <Link
                to="/app/editor/$id"
                params={{ id: d.id }}
                className="flex min-h-14 items-center justify-between px-4 py-3"
              >
                <span className="font-medium">{d.title}</span>
                <span className="text-xs text-muted">{d.updated_at.slice(0, 16)}</span>
              </Link>
            </li>
          ))
        )}
      </ul>

      <h2 className="mt-10 font-display text-2xl">Courses</h2>
      <form
        className="mt-3 flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          void joinCourse({ data: join })
            .then(() => refresh())
            .catch((ex) => setErr(String(ex)));
        }}
      >
        <input
          value={join}
          onChange={(e) => setJoin(e.target.value)}
          placeholder="Join code"
          className="min-h-11 flex-1 rounded-xl bg-surface px-3 shadow-[var(--shadow-border)]"
        />
        <Button type="submit" variant="outline">
          Enroll
        </Button>
      </form>
      <ul className="mt-4 space-y-2 text-sm">
        {courses.map((c) => (
          <li key={c.id} className="rounded-xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]">
            {c.code} · {c.title}
            {c.mine ? ` · join ${c.join_code}` : ""}
          </li>
        ))}
      </ul>
    </div>
  );
}
