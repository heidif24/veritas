import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { RequireAuth } from "@/components/gate";
import { Button } from "@/components/ui/button";
import { createAssignment, listMyCourses } from "@/lib/veritas/api";

export const Route = createFileRoute("/instructor/assignment/new")({ component: Page });

function Page() {
  return (
    <AppShell>
      <RequireAuth>
        <Form />
      </RequireAuth>
    </AppShell>
  );
}

function Form() {
  const nav = useNavigate();
  const [courses, setCourses] = useState<Awaited<ReturnType<typeof listMyCourses>>>([]);
  const [courseId, setCourseId] = useState("");
  const [title, setTitle] = useState("Week 6 response");
  const [paste, setPaste] = useState(15);
  const [sim, setSim] = useState(25);

  useEffect(() => {
    void listMyCourses().then((c) => {
      const mine = c.filter((x) => x.mine);
      setCourses(mine);
      if (mine[0]) setCourseId(mine[0].id);
    });
  }, []);

  return (
    <form
      className="max-w-lg space-y-4"
      onSubmit={(e) => {
        e.preventDefault();
        void createAssignment({
          data: {
            course_id: courseId,
            title,
            paste_threshold: paste / 100,
            similarity_threshold: sim / 100,
          },
        }).then(({ id }) => nav({ to: "/instructor/assignment/$id", params: { id } }));
      }}
    >
      <h1 className="font-display text-4xl tracking-tight">New assignment</h1>
      <label className="block text-sm text-muted">
        Course
        <select
          value={courseId}
          onChange={(e) => setCourseId(e.target.value)}
          className="mt-1 min-h-11 w-full rounded-xl bg-surface px-3 text-fg shadow-[var(--shadow-border)]"
        >
          {courses.map((c) => (
            <option key={c.id} value={c.id}>
              {c.code} · {c.title}
            </option>
          ))}
        </select>
      </label>
      <label className="block text-sm text-muted">
        Title
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="mt-1 min-h-11 w-full rounded-xl bg-surface px-3 text-fg shadow-[var(--shadow-border)]"
        />
      </label>
      <label className="block text-sm text-muted">
        Paste gate {paste}%
        <input
          type="range"
          min={5}
          max={80}
          value={paste}
          onChange={(e) => setPaste(Number(e.target.value))}
          className="mt-2 w-full"
        />
      </label>
      <label className="block text-sm text-muted">
        Similarity gate {sim}%
        <input
          type="range"
          min={5}
          max={80}
          value={sim}
          onChange={(e) => setSim(Number(e.target.value))}
        />
      </label>
      <Button type="submit" disabled={!courseId}>
        Create dropbox
      </Button>
    </form>
  );
}
