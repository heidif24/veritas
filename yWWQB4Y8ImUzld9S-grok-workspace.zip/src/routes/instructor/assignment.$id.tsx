import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { RequireAuth } from "@/components/gate";
import { loadAssignmentQueue } from "@/lib/veritas/api";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/instructor/assignment/$id")({ component: Page });

function Page() {
  return (
    <AppShell>
      <RequireAuth>
        <Queue />
      </RequireAuth>
    </AppShell>
  );
}

function risk(row: { paste_share: number; similarity: number; sha256: string | null }) {
  if (!row.sha256) return "unsigned";
  if (row.paste_share > 0.45) return "high-paste";
  if (row.similarity > 0.2) return "ai-risk";
  return "organic";
}

function Queue() {
  const { id } = Route.useParams();
  const [data, setData] = useState<Awaited<ReturnType<typeof loadAssignmentQueue>> | null>(null);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => {
    void loadAssignmentQueue({ data: id }).then(setData).catch((e) => setErr(String(e)));
  }, [id]);
  if (err) return <p className="text-primary">{err}</p>;
  if (!data) return <p className="text-muted">Loading queue…</p>;
  return (
    <div>
      <h1 className="font-display text-4xl tracking-tight">{data.assignment.title}</h1>
      <p className="mt-2 text-sm text-muted">
        Sorted by paste risk. Gates: paste {(data.assignment.paste_threshold * 100).toFixed(0)}% ·
        similarity {(data.assignment.similarity_threshold * 100).toFixed(0)}%
      </p>
      <ul className="mt-8 divide-y divide-border rounded-2xl bg-surface shadow-[var(--shadow-border)]">
        {data.rows.length === 0 ? (
          <li className="px-4 py-8 text-sm text-muted">No submissions yet.</li>
        ) : (
          data.rows.map((row) => (
            <li key={row.id}>
              <Link
                to="/instructor/report/$submissionId"
                params={{ submissionId: row.id }}
                className="flex flex-col gap-1 px-4 py-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <span className="text-sm">
                  {row.user_id.slice(0, 8)} · {row.created_at.slice(0, 16)}
                </span>
                <span className="flex items-center gap-3 text-sm tabular-nums">
                  <span
                    className={cn(
                      "rounded-full px-2 py-0.5 text-xs",
                      risk(row) === "organic" ? "bg-sage/10 text-sage" : "bg-primary/10 text-primary",
                    )}
                  >
                    {risk(row)}
                  </span>
                  <span>org {(row.organic * 100).toFixed(0)}%</span>
                  <span>paste {(row.paste_share * 100).toFixed(0)}%</span>
                </span>
              </Link>
            </li>
          ))
        )}
      </ul>
    </div>
  );
}
