import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { RequireAuth } from "@/components/gate";
import { loadReport } from "@/lib/veritas/api";
import { lineageForOps, type Op, type Telemetry } from "@/lib/veritas/ops";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/instructor/report/$submissionId")({
  component: Page,
});

function Page() {
  return (
    <AppShell>
      <RequireAuth>
        <Report />
      </RequireAuth>
    </AppShell>
  );
}

function Report() {
  const { submissionId } = Route.useParams();
  const [row, setRow] = useState<Awaited<ReturnType<typeof loadReport>> | null>(null);
  const [cursor, setCursor] = useState(1);
  useEffect(() => {
    void loadReport({ data: submissionId }).then(setRow);
  }, [submissionId]);
  const ops = useMemo(() => (row ? (JSON.parse(row.ops_json) as Op[]) : []), [row]);
  const tel = useMemo(
    () => (row ? (JSON.parse(row.telemetry_json) as Telemetry) : null),
    [row],
  );
  const sliced = ops.slice(0, Math.max(1, Math.round(cursor * ops.length)));
  const lineage = lineageForOps(sliced);
  if (!row || !tel) return <p className="text-muted">Loading report…</p>;
  return (
    <div>
      <h1 className="font-display text-4xl tracking-tight">Verdict</h1>
      <div className="mt-6 grid gap-3 sm:grid-cols-4">
        <Stat k="Organic" v={`${(row.organic * 100).toFixed(0)}%`} />
        <Stat k="Paste" v={`${(row.paste_share * 100).toFixed(0)}%`} />
        <Stat k="Similarity" v={`${(row.similarity * 100).toFixed(0)}%`} />
        <Stat k="Tab switches" v={String(row.tab_switches)} />
      </div>
      <p className="mt-4 text-sm text-muted">
        Tamper status: {row.sha256 ? "sealed hash present" : "unsigned"}
      </p>
      <h2 className="mt-10 font-display text-2xl">Replay</h2>
      <input
        type="range"
        min={0.02}
        max={1}
        step={0.02}
        value={cursor}
        onChange={(e) => setCursor(Number(e.target.value))}
        className="mt-3 w-full"
      />
      <p className="mt-4 min-h-40 whitespace-pre-wrap rounded-2xl bg-surface p-5 leading-relaxed shadow-[var(--shadow-border)]">
        {lineage.map((seg, i) => (
          <span
            key={i}
            className={
              seg.kind === "paste"
                ? "bg-primary/15"
                : seg.kind === "key"
                  ? "bg-sage/10"
                  : undefined
            }
          >
            {seg.text}
          </span>
        ))}
      </p>
      <p className="mt-3 text-xs text-muted">
        Sage = organic typing · Crimson = bulk paste
      </p>
      {row.package_json ? (
        <Button
          className="mt-6"
          variant="outline"
          onClick={() => {
            const blob = new Blob([row.package_json ?? ""], { type: "application/json" });
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = `${row.id}.veritas`;
            a.click();
            URL.revokeObjectURL(url);
          }}
        >
          Download sealed bundle
        </Button>
      ) : null}
    </div>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
      <p className="text-xs text-muted">{k}</p>
      <p className="mt-1 font-display text-2xl tabular-nums">{v}</p>
    </div>
  );
}
