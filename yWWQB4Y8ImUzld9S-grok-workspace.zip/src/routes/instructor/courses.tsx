import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { RequireAuth } from "@/components/gate";
import { Button } from "@/components/ui/button";
import { createCourse, listAssignments, listMyCourses } from "@/lib/veritas/api";

export const Route = createFileRoute("/instructor/courses")({ component: Page });

function Page() {
  return (
    <AppShell>
      <RequireAuth>
        <Courses />
      </RequireAuth>
    </AppShell>
  );
}

function Courses() {
  const [courses, setCourses] = useState<Awaited<ReturnType<typeof listMyCourses>>>([]);
  const [title, setTitle] = useState("CHEM 210");
  const [code, setCode] = useState("CHEM210");
  const [open, setOpen] = useState<Record<string, Array<{ id: string; title: string }>>>({});

  async function refresh() {
    const list = await listMyCourses();
    setCourses(list.filter((c) => c.mine));
  }
  useEffect(() => {
    void refresh();
  }, []);

  return (
    <div>
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">
            Instructor
          </p>
          <h1 className="mt-2 font-display text-4xl tracking-tight">Courses</h1>
        </div>
        <Link to="/instructor/assignment/new">
          <Button>New assignment</Button>
        </Link>
      </div>
      <form
        className="mt-6 flex flex-col gap-2 sm:flex-row"
        onSubmit={(e) => {
          e.preventDefault();
          void createCourse({ data: { title, code } }).then(() => refresh());
        }}
      >
        <input
          value={code}
          onChange={(e) => setCode(e.target.value)}
          className="min-h-11 rounded-xl bg-surface px-3 shadow-[var(--shadow-border)]"
          placeholder="Code"
        />
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="min-h-11 flex-1 rounded-xl bg-surface px-3 shadow-[var(--shadow-border)]"
          placeholder="Title"
        />
        <Button type="submit" variant="outline">
          Create course
        </Button>
      </form>
      <ul className="mt-8 space-y-3">
        {courses.map((c) => (
          <li key={c.id} className="rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="font-medium">
                  {c.code} · {c.title}
                </p>
                <p className="text-xs text-muted">Join code {c.join_code}</p>
              </div>
              <Button
                variant="ghost"
                onClick={() => {
                  void listAssignments({ data: c.id }).then((a) =>
                    setOpen((s) => ({ ...s, [c.id]: a })),
                  );
                }}
              >
                Assignments
              </Button>
            </div>
            {open[c.id]?.map((a) => (
              <Link
                key={a.id}
                to="/instructor/assignment/$id"
                params={{ id: a.id }}
                className="mt-2 block text-sm text-muted underline underline-offset-4"
              >
                {a.title}
              </Link>
            ))}
          </li>
        ))}
      </ul>
    </div>
  );
}
