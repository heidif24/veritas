import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { WritingCanvas, useBlankCanvas } from "@/components/writing-canvas";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const canvas = useBlankCanvas();
  return (
    <AppShell>
      <div className="max-w-2xl">
        <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">
          Zero download · browser native
        </p>
        <h1 className="mt-3 font-display text-4xl tracking-tight sm:text-5xl">
          Authorship you can seal, not just declare.
        </h1>
        <p className="mt-4 text-muted leading-relaxed">
          Veritas records how a draft is composed — keystrokes, pastes, pauses,
          focus loss — then hashes and Ed25519-signs a <code>.veritas</code>{" "}
          bundle. Edit it in Word and the verifier breaks. No extension. No install.
        </p>
        <div className="mt-6 flex flex-wrap gap-2">
          <Link to="/app/dashboard">
            <Button>Open workspace</Button>
          </Link>
          <Link to="/verify">
            <Button variant="outline">Verify a seal</Button>
          </Link>
        </div>
      </div>
      <div className="mt-10">
        <p className="mb-3 text-xs font-medium uppercase tracking-[0.14em] text-muted">
          Live telemetry demo
        </p>
        <WritingCanvas {...canvas} />
      </div>
      <dl className="mt-12 grid gap-4 sm:grid-cols-3">
        <Card t="Telemetry" d="Flight time, dwell, recursive edits, tab switches — in this tab only." />
        <Card t="Originality" d="5-gram windows against a campus corpus and prior submissions." />
        <Card t="Seal" d="SHA-256 + Ed25519. Re-upload after an external edit and it fails closed." />
      </dl>
    </AppShell>
  );
}

function Card({ t, d }: { t: string; d: string }) {
  return (
    <div className="rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]">
      <dt className="font-medium">{t}</dt>
      <dd className="mt-2 text-sm text-muted leading-relaxed">{d}</dd>
    </div>
  );
}
