import type { ButtonHTMLAttributes } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-xl text-sm font-medium transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary disabled:pointer-events-none disabled:opacity-40 min-h-11 px-4",
  {
    variants: {
      variant: {
        primary: "bg-primary text-surface hover:bg-primary/90",
        sage: "bg-sage text-surface hover:bg-sage/90",
        ink: "bg-fg text-bg hover:bg-fg/90",
        ghost: "bg-transparent text-fg hover:bg-fg/5",
        outline: "bg-surface text-fg hover:bg-bg",
      },
    },
    defaultVariants: { variant: "ink" },
  },
);

export function Button({
  className,
  variant,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof buttonVariants>) {
  return (
    <button className={cn(buttonVariants({ variant }), className)} {...props} />
  );
}
