import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { Op, Telemetry } from "@/lib/veritas/ops";
import { emptyTelemetry } from "@/lib/veritas/ops";
import { scoreHealth } from "@/lib/veritas/health";
import { HealthBar } from "@/components/health-bar";
import { highlightSpans, type MatchHit } from "@/lib/veritas/ngrams";

type Props = {
  body: string;
  ops: Op[];
  telemetry: Telemetry;
  onChange: (next: { body: string; ops: Op[]; telemetry: Telemetry }) => void;
  hits?: MatchHit[];
  footer?: ReactNode;
};

export function WritingCanvas({ body, ops, telemetry, onChange, hits, footer }: Props) {
  const prev = useRef(body);
  useEffect(() => {
    prev.current = body;
  }, [body]);
  const pasteRef = useRef(0);
  const tel = useRef(telemetry);
  tel.current = telemetry;
  const opsRef = useRef(ops);
  opsRef.current = ops;

  useEffect(() => {
    const onVis = () => {
      if (document.hidden) {
        const next = {
          ...tel.current,
          tabSwitches: tel.current.tabSwitches + 1,
          blurs: tel.current.blurs + 1,
        };
        onChange({ body: prev.current, ops: opsRef.current, telemetry: next });
      }
    };
    const onBlur = () => {
      const next = { ...tel.current, blurs: tel.current.blurs + 1 };
      onChange({ body: prev.current, ops: opsRef.current, telemetry: next });
    };
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("blur", onBlur);
    return () => {
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("blur", onBlur);
    };
  }, [onChange]);

  const health = useMemo(() => scoreHealth(ops, telemetry), [ops, telemetry]);
  const grams = (hits ?? []).map((h) => h.gram);
  const spans = useMemo(() => highlightSpans(body, grams), [body, grams]);

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_19rem]">
      <div>
        <label htmlFor="canvas" className="sr-only">
          Writing canvas
        </label>
        <textarea
          id="canvas"
          value={body}
          onPaste={(e) => {
            pasteRef.current = (e.clipboardData.getData("text") ?? "").length;
          }}
          onChange={(e) => {
            const next = e.target.value;
            const delta = next.length - prev.current.length;
            const now = Date.now();
            let op: Op;
            if (pasteRef.current > 0) {
              op = {
                t: now,
                kind: "paste",
                chars: pasteRef.current,
                text: next.slice(Math.max(0, next.length - pasteRef.current)),
              };
              pasteRef.current = 0;
            } else if (delta < 0) {
              op = { t: now, kind: "delete", chars: -delta };
            } else {
              op = {
                t: now,
                kind: "key",
                chars: Math.max(1, delta),
                text: next.slice(Math.max(0, prev.current.length)),
              };
            }
            prev.current = next;
            onChange({
              body: next,
              ops: [...opsRef.current, op],
              telemetry: { ...tel.current, lastInputAt: now },
            });
          }}
          placeholder="Compose here. Paste, tab away, or type — Veritas records the ledger in this browser."
          className="min-h-[24rem] w-full resize-y rounded-2xl bg-surface p-5 text-base leading-relaxed shadow-[var(--shadow-border)] placeholder:text-muted/80 focus:outline-2 focus:outline-offset-2 focus:outline-primary"
        />
        {spans.some((s) => s.hit) ? (
          <p className="mt-3 text-sm leading-relaxed">
            {spans.map((s, i) => (
              <span
                key={i}
                className={s.hit ? "underline decoration-amber decoration-2 underline-offset-4" : undefined}
              >
                {s.text}
              </span>
            ))}
          </p>
        ) : null}
        {footer}
      </div>
      <HealthBar health={health} />
    </div>
  );
}

export function useBlankCanvas() {
  const [body, setBody] = useState("");
  const [ops, setOps] = useState<Op[]>([]);
  const [telemetry, setTelemetry] = useState<Telemetry>(emptyTelemetry);
  return {
    body,
    ops,
    telemetry,
    onChange: (n: { body: string; ops: Op[]; telemetry: Telemetry }) => {
      setBody(n.body);
      setOps(n.ops);
      setTelemetry(n.telemetry);
    },
  };
}
