import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { SignedIn, SignedOut, UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/verify", label: "Verify" },
  { to: "/app/dashboard", label: "Workspace" },
  { to: "/instructor/courses", label: "Instructor" },
  { to: "/admin/tenant", label: "Admin" },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const { user, isPending } = useCurrentUserState();
  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="sticky top-0 z-20 border-b border-border/80 bg-bg/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <Link to="/" className="flex min-h-11 items-center gap-2.5">
            <span className="grid size-8 place-items-center rounded-full bg-fg text-bg font-display text-sm">
              V
            </span>
            <span className="font-display text-lg tracking-tight">Veritas</span>
          </Link>
          <nav className="hidden items-center gap-1 sm:flex">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="flex min-h-11 items-center rounded-full px-3 text-sm text-muted hover:text-fg"
                activeProps={{ className: "text-fg bg-fg/5" }}
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="flex min-h-11 items-center">
            {isPending ? (
              <div className="size-8 animate-pulse rounded-full bg-fg/10" />
            ) : user ? (
              <SignedIn>
                <UserButton />
              </SignedIn>
            ) : (
              <SignedOut>
                <Link
                  to="/login"
                  className="flex min-h-11 items-center rounded-full bg-fg px-4 text-sm text-bg"
                >
                  Sign in
                </Link>
              </SignedOut>
            )}
          </div>
        </div>
      </header>
      <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-10">{children}</div>
    </div>
  );
}
