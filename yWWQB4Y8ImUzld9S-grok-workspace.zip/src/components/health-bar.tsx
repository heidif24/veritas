import type { Health } from "@/lib/veritas/health";
import { cn } from "@/lib/utils";

export function HealthBar({ health }: { health: Health }) {
  const organicPct = Math.round(health.organic * 100);
  const pastePct = Math.round(health.pasteShare * 100);
  return (
    <section className="rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]">
      <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">
        Composition health
      </p>
      <p className="mt-2 font-display text-2xl tracking-tight">
        {organicPct}% organic
      </p>
      <div className="mt-3 flex h-2 overflow-hidden rounded-full bg-border">
        <div className="bg-sage" style={{ width: `${organicPct}%` }} />
        <div className="bg-primary" style={{ width: `${pastePct}%` }} />
      </div>
      <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
        <div>
          <dt className="text-xs text-muted">Paste</dt>
          <dd className="tabular-nums">{pastePct}%</dd>
        </div>
        <div>
          <dt className="text-xs text-muted">Tab switches</dt>
          <dd className="tabular-nums">{health.tabSwitches}</dd>
        </div>
        <div>
          <dt className="text-xs text-muted">Median flight</dt>
          <dd className="tabular-nums">
            {health.medianFlight != null ? `${Math.round(health.medianFlight)} ms` : "—"}
          </dd>
        </div>
        <div>
          <dt className="text-xs text-muted">Risk</dt>
          <dd className={cn(health.risk === "organic" ? "text-sage" : "text-primary")}>
            {health.risk}
          </dd>
        </div>
      </dl>
      <ul className="mt-4 space-y-1.5 text-sm text-muted">
        {health.notes.map((n) => (
          <li key={n}>{n}</li>
        ))}
      </ul>
    </section>
  );
}
