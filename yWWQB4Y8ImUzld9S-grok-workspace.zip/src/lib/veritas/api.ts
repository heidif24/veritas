import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { scoreHealth } from "@/lib/veritas/health";
import { similarityAgainst } from "@/lib/veritas/ngrams";
import { sealPayload, verifyBundle, sha256Json, type VeritasPayload } from "@/lib/veritas/crypto.server";
import type { Op, Telemetry } from "@/lib/veritas/ops";
import { emptyTelemetry } from "@/lib/veritas/ops";

function nid() {
  return crypto.randomUUID();
}

async function ensureProfile(userId: string) {
  const sql = await getSql();
  await sql`insert into profiles (user_id, role, display_name) values (${userId}, 'student', 'Writer') on conflict (user_id) do nothing`;
}

export const getMe = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await ensureProfile(context.userId);
    const sql = await getSql();
    const rows = await sql<{
      user_id: string;
      role: string;
      display_name: string | null;
      institution: string;
      domain: string;
    }>`select user_id, role, display_name, institution, domain from profiles where user_id = ${context.userId}`;
    return rows[0]!;
  });

export const setRole = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { role: string; display_name?: string; institution?: string; domain?: string }) => d)
  .handler(async ({ context, data }) => {
    const role = ["student", "instructor", "admin"].includes(data.role) ? data.role : "student";
    const sql = await getSql();
    await ensureProfile(context.userId);
    await sql`update profiles set role = ${role}, display_name = coalesce(${data.display_name ?? null}, display_name), institution = coalesce(${data.institution ?? null}, institution), domain = coalesce(${data.domain ?? null}, domain) where user_id = ${context.userId}`;
    return { ok: true as const };
  });

export const listDocuments = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    return sql<{
      id: string;
      title: string;
      updated_at: string;
      assignment_id: string | null;
    }>`select id, title, updated_at::text as updated_at, assignment_id from documents where user_id = ${context.userId} order by updated_at desc`;
  });

export const createDocument = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { title?: string; assignment_id?: string | null }) => d)
  .handler(async ({ context, data }) => {
    const id = nid();
    const sql = await getSql();
    await sql`insert into documents (id, user_id, assignment_id, title) values (${id}, ${context.userId}, ${data.assignment_id ?? null}, ${data.title?.trim() || "Untitled draft"})`;
    return { id };
  });

export const loadDocument = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((id: string) => id)
  .handler(async ({ context, data: id }) => {
    const sql = await getSql();
    const rows = await sql<{
      id: string;
      title: string;
      body: string;
      ops_json: string;
      telemetry_json: string;
      assignment_id: string | null;
    }>`select id, title, body, ops_json, telemetry_json, assignment_id from documents where id = ${id} and user_id = ${context.userId}`;
    const row = rows[0];
    if (!row) throw new Error("Document not found");
    return row;
  });

export const saveDocument = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (d: {
      id: string;
      title: string;
      body: string;
      ops: Op[];
      telemetry: Telemetry;
      assignment_id?: string | null;
    }) => d,
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`update documents set title = ${data.title}, body = ${data.body}, ops_json = ${JSON.stringify(data.ops)}, telemetry_json = ${JSON.stringify(data.telemetry)}, assignment_id = ${data.assignment_id ?? null}, updated_at = now() where id = ${data.id} and user_id = ${context.userId}`;
    return { ok: true as const };
  });

export const listCorpus = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async () => {
    const sql = await getSql();
    return sql<{ id: string; title: string; source_url: string | null; body: string }>`select id, title, source_url, body from corpus`;
  });

export const checkOriginality = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { text: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const corpus = await sql<{
      id: string;
      title: string;
      source_url: string | null;
      body: string;
    }>`select id, title, source_url, body from corpus`;
    const prior = await sql<{
      id: string;
      title: string;
      source_url: string | null;
      body: string;
    }>`select id, 'Prior submission'::text as title, null::text as source_url, body from submissions where user_id <> ${context.userId}`;
    return similarityAgainst(data.text, [...corpus, ...prior]);
  });

export const listMyCourses = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const owned = await sql<{
      id: string;
      title: string;
      code: string;
      join_code: string;
      mine: boolean;
    }>`select id, title, code, join_code, true as mine from courses where user_id = ${context.userId}`;
    const enrolled = await sql<{
      id: string;
      title: string;
      code: string;
      join_code: string;
      mine: boolean;
    }>`select c.id, c.title, c.code, c.join_code, false as mine from courses c join enrollments e on e.course_id = c.id where e.user_id = ${context.userId}`;
    return [...owned, ...enrolled];
  });

export const createCourse = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { title: string; code: string }) => d)
  .handler(async ({ context, data }) => {
    const id = nid();
    const join = Math.random().toString(36).slice(2, 8).toUpperCase();
    const sql = await getSql();
    await sql`insert into courses (id, user_id, title, code, join_code) values (${id}, ${context.userId}, ${data.title.trim()}, ${data.code.trim()}, ${join})`;
    return { id, join_code: join };
  });

export const joinCourse = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((code: string) => code.trim().toUpperCase())
  .handler(async ({ context, data: code }) => {
    const sql = await getSql();
    const rows = await sql<{ id: string }>`select id from courses where join_code = ${code}`;
    const course = rows[0];
    if (!course) throw new Error("Unknown join code");
    await sql`insert into enrollments (course_id, user_id) values (${course.id}, ${context.userId}) on conflict do nothing`;
    return { id: course.id };
  });

export const createAssignment = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (d: {
      course_id: string;
      title: string;
      paste_threshold: number;
      similarity_threshold: number;
    }) => d,
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const own = await sql<{ id: string }>`select id from courses where id = ${data.course_id} and user_id = ${context.userId}`;
    if (!own[0]) throw new Error("Course not found");
    const id = nid();
    await sql`insert into assignments (id, course_id, user_id, title, paste_threshold, similarity_threshold) values (${id}, ${data.course_id}, ${context.userId}, ${data.title.trim()}, ${data.paste_threshold}, ${data.similarity_threshold})`;
    return { id };
  });

export const listAssignments = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((courseId: string) => courseId)
  .handler(async ({ context, data: courseId }) => {
    const sql = await getSql();
    const access = await sql<{ id: string }>`
      select id from courses where id = ${courseId} and user_id = ${context.userId}
      union
      select c.id from courses c join enrollments e on e.course_id = c.id where c.id = ${courseId} and e.user_id = ${context.userId}
    `;
    if (!access[0]) throw new Error("No access");
    return sql<{
      id: string;
      title: string;
      paste_threshold: number;
      similarity_threshold: number;
    }>`select id, title, paste_threshold, similarity_threshold from assignments where course_id = ${courseId} order by created_at desc`;
  });

export const loadAssignmentQueue = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((assignmentId: string) => assignmentId)
  .handler(async ({ context, data: assignmentId }) => {
    const sql = await getSql();
    const asg = await sql<{
      id: string;
      title: string;
      paste_threshold: number;
      similarity_threshold: number;
    }>`select a.id, a.title, a.paste_threshold, a.similarity_threshold from assignments a join courses c on c.id = a.course_id where a.id = ${assignmentId} and c.user_id = ${context.userId}`;
    const assignment = asg[0];
    if (!assignment) throw new Error("Assignment not found");
    const rows = await sql<{
      id: string;
      user_id: string;
      organic: number;
      paste_share: number;
      similarity: number;
      tab_switches: number;
      sha256: string | null;
      created_at: string;
    }>`select id, user_id, organic, paste_share, similarity, tab_switches, sha256, created_at::text as created_at from submissions where assignment_id = ${assignmentId} order by paste_share desc, created_at desc`;
    return { assignment, rows };
  });

export const loadReport = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((submissionId: string) => submissionId)
  .handler(async ({ context, data: submissionId }) => {
    const sql = await getSql();
    const rows = await sql<{
      id: string;
      user_id: string;
      body: string;
      ops_json: string;
      telemetry_json: string;
      organic: number;
      paste_share: number;
      similarity: number;
      tab_switches: number;
      sha256: string | null;
      package_json: string | null;
      created_at: string;
      assignment_id: string | null;
    }>`
      select s.id, s.user_id, s.body, s.ops_json, s.telemetry_json, s.organic, s.paste_share, s.similarity, s.tab_switches, s.sha256, s.package_json, s.created_at::text as created_at, s.assignment_id
      from submissions s
      left join assignments a on a.id = s.assignment_id
      left join courses c on c.id = a.course_id
      where s.id = ${submissionId} and (s.user_id = ${context.userId} or c.user_id = ${context.userId})
    `;
    const row = rows[0];
    if (!row) throw new Error("Report not found");
    return row;
  });

export const submitAndSeal = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (d: {
      document_id: string;
      assignment_id?: string | null;
      title: string;
      body: string;
      ops: Op[];
      telemetry: Telemetry;
      force?: boolean;
    }) => d,
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const health = scoreHealth(data.ops, data.telemetry);
    const corpus = await sql<{
      id: string;
      title: string;
      source_url: string | null;
      body: string;
    }>`select id, title, source_url, body from corpus`;
    const prior = await sql<{
      id: string;
      title: string;
      source_url: string | null;
      body: string;
    }>`select id, 'Prior submission'::text as title, null::text as source_url, body from submissions where user_id <> ${context.userId}`;
    const originality = similarityAgainst(data.body, [...corpus, ...prior]);

    let pasteGate = 0.15;
    let simGate = 0.25;
    if (data.assignment_id) {
      const asg = await sql<{ paste_threshold: number; similarity_threshold: number }>`select paste_threshold, similarity_threshold from assignments where id = ${data.assignment_id}`;
      if (asg[0]) {
        pasteGate = Number(asg[0].paste_threshold);
        simGate = Number(asg[0].similarity_threshold);
      }
    }
    if (!data.force && (health.pasteShare > pasteGate || originality.score > simGate)) {
      return {
        blocked: true as const,
        pasteGate,
        simGate,
        health,
        originality,
      };
    }

    const payload: VeritasPayload = {
      authorId: context.userId,
      title: data.title,
      text: data.body,
      ops: data.ops,
      telemetry: data.telemetry,
      assignmentId: data.assignment_id ?? null,
      sealedAt: new Date().toISOString(),
    };
    const bundle = await sealPayload(payload);
    const id = nid();
    await sql`insert into submissions (id, document_id, assignment_id, user_id, body, ops_json, telemetry_json, organic, paste_share, similarity, tab_switches, package_json, sha256)
      values (${id}, ${data.document_id}, ${data.assignment_id ?? null}, ${context.userId}, ${data.body}, ${JSON.stringify(data.ops)}, ${JSON.stringify(data.telemetry)}, ${health.organic}, ${health.pasteShare}, ${originality.score}, ${health.tabSwitches}, ${JSON.stringify(bundle)}, ${bundle.sha256})`;
    return {
      blocked: false as const,
      id,
      bundle,
      health,
      originality,
      pasteGate,
      simGate,
    };
  });

export const verifyPackageFn = createServerFn({ method: "POST" })
  .validator((bundle: unknown) => bundle)
  .handler(async ({ data }) => {
    const b = data as {
      payload?: VeritasPayload;
      sha256?: string;
      signature?: string;
      publicKeyPem?: string;
    };
    if (!b?.payload || !b.sha256 || !b.signature || !b.publicKeyPem) {
      return { ok: false, reason: "Not a Veritas bundle.", sha256: "", recomputed: "" };
    }
    const result = verifyBundle({
      payload: b.payload,
      sha256: b.sha256,
      signature: b.signature,
      publicKeyPem: b.publicKeyPem,
    });
    return { ...result, sha256: b.sha256, recomputed: sha256Json(b.payload) };
  });

export const saveTenant = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { branding: Record<string, string>; lti: Record<string, string> }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`insert into tenant_settings (user_id, branding_json, lti_json) values (${context.userId}, ${JSON.stringify(data.branding)}, ${JSON.stringify(data.lti)})
      on conflict (user_id) do update set branding_json = ${JSON.stringify(data.branding)}, lti_json = ${JSON.stringify(data.lti)}`;
    return { ok: true as const };
  });

export const loadTenant = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql<{ branding_json: string; lti_json: string }>`select branding_json, lti_json from tenant_settings where user_id = ${context.userId}`;
    if (!rows[0]) return { branding: {}, lti: {} };
    return {
      branding: JSON.parse(rows[0].branding_json) as Record<string, string>,
      lti: JSON.parse(rows[0].lti_json) as Record<string, string>,
    };
  });

export const listFaculty = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    return sql<{
      user_id: string;
      role: string;
      display_name: string | null;
      institution: string;
    }>`select user_id, role, display_name, institution from profiles where user_id = ${context.userId} or role in ('instructor','admin') order by role`;
  });
