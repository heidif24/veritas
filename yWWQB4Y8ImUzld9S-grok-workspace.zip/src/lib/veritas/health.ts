import type { Op, Telemetry } from "@/lib/veritas/ops";

export type Health = {
  organic: number;
  pasteShare: number;
  transcribed: number;
  tabSwitches: number;
  blurs: number;
  medianFlight: number | null;
  revisionRatio: number;
  risk: "organic" | "high-paste" | "ai-risk" | "mixed";
  notes: string[];
};

function median(values: number[]): number | null {
  if (!values.length) return null;
  const s = [...values].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid]! : (s[mid - 1]! + s[mid]!) / 2;
}

export function scoreHealth(ops: Op[], telemetry: Telemetry): Health {
  let typed = 0;
  let pasted = 0;
  let deleted = 0;
  const flights: number[] = [];
  let prev: number | null = null;
  for (const op of ops) {
    if (op.kind === "paste") pasted += op.chars;
    else if (op.kind === "delete") deleted += op.chars;
    else if (op.kind === "key") {
      typed += op.chars;
      if (prev != null) {
        const g = op.t - prev;
        if (g > 12 && g < 2500) flights.push(g);
      }
      prev = op.t;
    } else prev = null;
  }
  const total = typed + pasted || 1;
  const pasteShare = pasted / total;
  const revisionRatio = typed ? deleted / typed : 0;
  const medianFlight = median(flights);
  let transcribed = 0;
  if (medianFlight != null && medianFlight < 40 && flights.length > 24) transcribed = 0.35;
  const organic = Math.max(0, Math.min(1, 1 - pasteShare - transcribed * 0.5));
  const notes: string[] = [];
  if (pasteShare > 0.15) notes.push("Paste volume exceeds a typical 15% institutional gate.");
  if (transcribed > 0) notes.push("Keystroke flight times look like transcription, not composing.");
  if (telemetry.tabSwitches > 4) notes.push(`${telemetry.tabSwitches} focus losses during the session.`);
  if (revisionRatio < 0.02 && typed > 80) notes.push("Almost no recursive editing.");
  if (!notes.length) notes.push("Composition pattern is consistent with in-browser drafting.");

  let risk: Health["risk"] = "organic";
  if (pasteShare > 0.45) risk = "high-paste";
  else if (transcribed > 0 || pasteShare > 0.15) risk = "ai-risk";
  else if (pasteShare > 0.05) risk = "mixed";

  return {
    organic,
    pasteShare,
    transcribed,
    tabSwitches: telemetry.tabSwitches,
    blurs: telemetry.blurs,
    medianFlight,
    revisionRatio,
    risk,
    notes,
  };
}
