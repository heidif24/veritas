export function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\u00c0-\u024f\s]+/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 1);
}

export function ngrams(words: string[], n = 5): string[] {
  if (words.length < n) return words.length ? [words.join(" ")] : [];
  const out: string[] = [];
  for (let i = 0; i <= words.length - n; i++) {
    out.push(words.slice(i, i + n).join(" "));
  }
  return out;
}

export type MatchHit = {
  sourceId: string;
  title: string;
  sourceUrl: string | null;
  gram: string;
  overlap: number;
};

export function similarityAgainst(
  text: string,
  corpus: Array<{ id: string; title: string; source_url: string | null; body: string }>,
): { score: number; hits: MatchHit[] } {
  const grams = new Set(ngrams(tokenize(text), 5));
  if (!grams.size) return { score: 0, hits: [] };
  const hits: MatchHit[] = [];
  let best = 0;
  for (const doc of corpus) {
    const other = ngrams(tokenize(doc.body), 5);
    if (!other.length) continue;
    let hit = 0;
    const sample: string[] = [];
    for (const g of other) {
      if (grams.has(g)) {
        hit += 1;
        if (sample.length < 4) sample.push(g);
      }
    }
    const overlap = hit / Math.max(other.length, grams.size);
    if (overlap > best) best = overlap;
    if (overlap > 0.02 && sample.length) {
      hits.push({
        sourceId: doc.id,
        title: doc.title,
        sourceUrl: doc.source_url,
        gram: sample[0]!,
        overlap,
      });
    }
  }
  hits.sort((a, b) => b.overlap - a.overlap);
  return { score: best, hits: hits.slice(0, 8) };
}

export function highlightSpans(text: string, grams: string[]): Array<{ text: string; hit: boolean }> {
  if (!grams.length || !text) return [{ text, hit: false }];
  const lower = text.toLowerCase();
  const marks: Array<{ start: number; end: number }> = [];
  for (const g of grams) {
    let from = 0;
    const needle = g.toLowerCase();
    while (from < lower.length) {
      const i = lower.indexOf(needle, from);
      if (i < 0) break;
      marks.push({ start: i, end: i + needle.length });
      from = i + needle.length;
    }
  }
  if (!marks.length) return [{ text, hit: false }];
  marks.sort((a, b) => a.start - b.start);
  const merged: typeof marks = [];
  for (const m of marks) {
    const last = merged[merged.length - 1];
    if (last && m.start <= last.end) last.end = Math.max(last.end, m.end);
    else merged.push({ ...m });
  }
  const spans: Array<{ text: string; hit: boolean }> = [];
  let cursor = 0;
  for (const m of merged) {
    if (m.start > cursor) spans.push({ text: text.slice(cursor, m.start), hit: false });
    spans.push({ text: text.slice(m.start, m.end), hit: true });
    cursor = m.end;
  }
  if (cursor < text.length) spans.push({ text: text.slice(cursor), hit: false });
  return spans;
}
