export type OpKind = "key" | "paste" | "delete" | "idle";

export type Op = {
  t: number;
  kind: OpKind;
  text?: string;
  chars: number;
};

export type Telemetry = {
  tabSwitches: number;
  blurs: number;
  dwellSamples: number[];
  startedAt: number;
  lastInputAt: number;
};

export function emptyTelemetry(): Telemetry {
  return {
    tabSwitches: 0,
    blurs: 0,
    dwellSamples: [],
    startedAt: Date.now(),
    lastInputAt: Date.now(),
  };
}

export function lineageForOps(ops: Op[]): Array<{ text: string; kind: OpKind }> {
  const out: Array<{ text: string; kind: OpKind }> = [];
  for (const op of ops) {
    if (op.kind === "delete") {
      let remain = op.chars;
      while (remain > 0 && out.length) {
        const last = out[out.length - 1]!;
        if (last.text.length <= remain) {
          remain -= last.text.length;
          out.pop();
        } else {
          last.text = last.text.slice(0, last.text.length - remain);
          remain = 0;
        }
      }
    } else if (op.text) {
      out.push({ text: op.text, kind: op.kind });
    }
  }
  return out;
}

export function reconstruct(ops: Op[]): string {
  return lineageForOps(ops)
    .map((s) => s.text)
    .join("");
}
