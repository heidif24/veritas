import { createHash, generateKeyPairSync, sign, verify } from "node:crypto";
import { getSql } from "@/lib/db";

type KeyRow = { public_pem: string; private_pem: string };

export type VeritasPayload = {
  authorId: string;
  title: string;
  text: string;
  ops: unknown[];
  telemetry: Record<string, unknown>;
  assignmentId: string | null;
  sealedAt: string;
};

export type VeritasBundle = {
  version: 1;
  format: "veritas";
  payload: VeritasPayload;
  sha256: string;
  signature: string;
  publicKeyPem: string;
};

async function loadKeys(): Promise<KeyRow> {
  const sql = await getSql();
  const existing = await sql<KeyRow>`select public_pem, private_pem from tenant_keys where id = 1`;
  if (existing[0]) return existing[0];
  const pair = generateKeyPairSync("ed25519");
  const public_pem = pair.publicKey.export({ type: "spki", format: "pem" }).toString();
  const private_pem = pair.privateKey.export({ type: "pkcs8", format: "pem" }).toString();
  await sql`insert into tenant_keys (id, public_pem, private_pem) values (1, ${public_pem}, ${private_pem}) on conflict (id) do nothing`;
  return { public_pem, private_pem };
}

export function sha256Json(payload: VeritasPayload | Record<string, unknown>): string {
  const canonical = JSON.stringify(payload);
  return createHash("sha256").update(canonical).digest("hex");
}

export async function sealPayload(payload: VeritasPayload): Promise<VeritasBundle> {
  const keys = await loadKeys();
  const sha256 = sha256Json(payload);
  const signature = sign(null, Buffer.from(sha256, "utf8"), keys.private_pem).toString("base64");
  return {
    version: 1,
    format: "veritas",
    payload,
    sha256,
    signature,
    publicKeyPem: keys.public_pem,
  };
}

export function verifyBundle(bundle: {
  payload: VeritasPayload;
  sha256: string;
  signature: string;
  publicKeyPem: string;
}): { ok: boolean; reason: string } {
  const expected = sha256Json(bundle.payload);
  if (expected !== bundle.sha256) {
    return {
      ok: false,
      reason:
        "CRITICAL TAMPER ALERT: Document integrity broken post-export. File has been modified outside the secure Veritas environment.",
    };
  }
  try {
    const good = verify(
      null,
      Buffer.from(bundle.sha256, "utf8"),
      bundle.publicKeyPem,
      Buffer.from(bundle.signature, "base64"),
    );
    if (!good) {
      return {
        ok: false,
        reason:
          "CRITICAL TAMPER ALERT: Digital signature does not match the platform key. File has been modified outside the secure Veritas environment.",
      };
    }
  } catch {
    return { ok: false, reason: "CRITICAL TAMPER ALERT: Signature could not be verified." };
  }
  return { ok: true, reason: "Sealed. Hash and Ed25519 signature match." };
}
